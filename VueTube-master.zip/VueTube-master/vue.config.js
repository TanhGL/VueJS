module.exports = {
  devServer: {
    proxy: 'https://pipedapi.kavin.rocks',
  },
};
